---
name: rc-beam-aci318m19
description: ออกแบบ (เลือกเหล็กบน/ล่าง ปลอก และความยาวเหล็กพิเศษให้อัตโนมัติ) และตรวจสอบคาน คสล. หน้าตัดสี่เหลี่ยมทั้งช่วง (ปลายซ้าย กลางช่วง ปลายขวา) ทุก load combination ตาม ACI 318M-19 โดยใช้ knowledge base ของโครงการใน kb/ เป็นแหล่งอ้างอิงหลัก ครอบคลุมแรงดัด strain compatibility (เหล็กหลายชั้น นับเหล็กอัด), tension-controlled, As,min, แรงเฉือนแยกโซน, คานในโครง OMF/IMF, ระยะว่าง คุมรอยร้าว ความลึกขั้นต่ำ, จุดตัดเหล็กบน ℓd ℓdh ระยะทาบ และ structural integrity อินพุต kgf-m (ksc, tf) หรือ SI รายงานทุกหัวข้ออ้างไฟล์และข้อใน KB ใช้เมื่อผู้ใช้พูดถึง "ออกแบบคาน", "ตรวจคาน", "beam", "เหล็กบน", "เหล็กล่าง", "เหล็กเสริมพิเศษ", "ปลอกคาน", "stirrup", "φMn", "ระยะทาบ", "ตัดเหล็ก", "คาน STAAD", "คาน IMF" ไม่ใช่สำหรับเสา (rc-column-aci318m19), คาน T, deep beam, คานอัดแรง หรือคาน SMF
---

# คาน คสล. ACI 318M-19 — beamkit

ผลลัพธ์ใช้ประกอบรายการคำนวณ วิศวกรผู้รับผิดชอบต้องตรวจและลงนามเอง

## กฎ

1. **KB มาก่อน** — คำถามข้อกำหนดให้เปิด `kb/INDEX.md` แล้วอ่านไฟล์บทที่เกี่ยวข้อง ตอบพร้อม § และชื่อไฟล์ ถ้า KB ไม่มีให้บอกว่าไม่มี ห้ามเติมจากความจำโดยไม่บอก
2. **ค่า SI** — ใช้ `references/si-formulas.md` และ `references/si-constants-318m.md` (KB เป็นหน่วย inch-pound)
3. **ตัวเลขทุกตัวมาจาก `scripts/beam.py`** — ห้ามคำนวณเองในหัว
4. **ห้ามเดาอินพุต** ที่มีผลต่อผล: f′c, fy, fyt, b, h, ℓn, ระบบ (null/OMF/IMF), ตำแหน่งคาน (ริม/ภายใน), แรงทุก combo ที่ 3 หน้าตัด → ถาม ค่าที่มี default ใช้ได้แต่ต้องแจ้งผู้ใช้
5. **หน่วยไทย:** ksc × 0.0980665 = MPa — SD40 = 392.3 MPa (ไม่ใช่ 420), SR24 = 235.4 MPa
6. ห้ามสรุป "ผ่านทั้งหมด" ถ้ารายงานยังมีหัวข้อ "ยังไม่ตรวจ" — ต้องย้ำรายการนั้นทุกครั้ง
7. รัน `python3 scripts/test_beam.py` ครั้งแรกในเซสชัน ต้องผ่านทั้งหมด

## Workflow (ทีละช่วงคาน)

| ขั้น | งาน | KB |
|---|---|---|
| 0 | ขอบเขต + ระบบ: deep beam / Pu ≥ 0.1f′cAg / SMF → **หยุด** | chapter-09, 18 |
| 1 | หน้าตัด วัสดุ ระยะหุ้ม | chapter-20, 22 |
| 2 | แรงจาก STAAD ทุก combo: M ที่ผิวจุดรองรับซ้าย, กลางช่วง, ผิวจุดรองรับขวา; V ที่หน้าตัดวิกฤต | chapter-09 §9.4 |
| 3 | แรงดัดทั้ง 6 จุด (3 หน้าตัด × บน/ล่าง) | chapter-22, 21, 09 |
| 4 | แรงเฉือนแยก 3 โซน (ปลายซ้าย / กลาง / ปลายขวา) | chapter-22 §22.5, 09 |
| 5 | OMF/IMF: เหล็กต่อเนื่อง, Mn⁺ ≥ Mn⁻/3, Ve, hoop ช่วง 2h | chapter-18 |
| 6 | ระยะว่าง, คุมรอยร้าว, ความลึกขั้นต่ำ | chapter-25, 24, 09 |
| 7 | ความยาวเหล็กบนพิเศษ, ℓd, ℓdh, ทาบ | chapter-09 §9.7.3, 25 |
| 8 | Structural integrity | chapter-09 §9.7.7 |
| 9 | สรุป + รายการยังไม่ตรวจ | — |

ขั้นตอน:
1. รวบรวมอินพุต → เขียน JSON (แบบใน `examples/`) — คานต่อเนื่องหลายช่วงให้รันทีละช่วง
2. `python3 scripts/beam.py input.json` (`--json` ได้ผลดิบ) — exit 0 = ผ่าน, 1 = ไม่ผ่านหรือหยุด
3. ไม่ผ่าน: εt ไม่ถึง/เหล็กไม่พอ → เพิ่มความลึก; เฉือนเกิน §22.5.1.2 → ขยายหน้าตัด; ปลอกถี่เกิน → เพิ่มขา แล้วรันใหม่
4. ส่งรายงานทั้งฉบับและสรุปสั้น ๆ เป็นภาษาไทย

## อินพุตจาก STAAD.Pro (แนะนำ)

ถ้าผู้ใช้มีไฟล์ `.std` และตารางแรงจาก STAAD (คัดลอกตาราง **Beam Section Forces** หรือ Beam End Forces วางเป็นข้อความ, หน่วย kN–m) **ห้ามแปลงเครื่องหมายเอง** ให้ใช้:

```
python3 scripts/from_staad.py model.std forces.txt --kind beam --member <เลข> --lc <combo ...> --fc <f′c ทรงกระบอก> --fy <MPa> -o input.json
python3 scripts/beam.py input.json
```

- สคริปต์อ่านแกน local, YD/ZD, start/end เอง ตามกฎใน `references/staad-sign-convention.md` (ยืนยันกับผล STAAD จริง) และใส่ตาราง "ที่มาของแรง" ในรายงานให้ตรวจย้อนได้
- **f′c ต้องถามผู้ใช้** — STAAD เก็บ FCU (กำลังลูกบาศก์) ไม่ใช่ f′c ทรงกระบอก · ใช้เฉพาะ combo กำลัง (ไม่ใช้ combo service)
- คาน: **ต้องใช้ตาราง Beam Section Forces** (ตาราง End Forces ไม่มีกลางช่วง) · M, V คิดที่ผิวเสา · ใส่ `--position perimeter|interior` และ `--support` ด้วย
- สคริปต์หยุดเมื่อเจอ BETA ≠ 0, สมาชิกเอียง, หน้าตัดที่ไม่ใช่ PRIS — บอกผู้ใช้และขอข้อมูลเพิ่ม

## โหมด

- `"mode": "design"` — เหล็กล่างต่อเนื่องตลอดช่วง (เลือกจากโมเมนต์บวกมากสุด), เหล็กบนต่อเนื่อง ≥ 2 เส้น + เหล็กเสริมพิเศษที่แต่ละจุดรองรับ (ขนาดเดียวกัน), ไล่ขนาดใน `design.db_options` แล้วเลือก As น้อยสุดที่ผ่าน; ปลอกเลือกระยะมากสุด (ทีละ 25 mm) ที่ผ่านทุกข้อ แยกโซนปลายกับกลาง; IMF เพิ่มเหล็กล่างให้ผ่าน §18.4.2.2 อัตโนมัติ; คานริมเพิ่มเหล็กบนต่อเนื่องตาม §9.7.7.1
- `"mode": "check"` — ตรวจตาม `bars` และ `stirrups` ที่ให้

## อินพุต JSON

| key | ความหมาย | kgf-m | SI | default |
|---|---|---|---|---|
| `mode` | `design` / `check` | | | design |
| `units` | `kgf-m` / `SI` | | | kgf-m |
| `system` | `null` / `OMF` / `IMF` (`SMF` หยุด) | | | null |
| `section` | `{b, h}` | m | mm | **ต้องให้** |
| `materials` | `{fc, fy, fyt}` | ksc | MPa | fyt = fy |
| `cover`, `dagg` | ระยะหุ้มถึงผิวปลอก, มวลรวมโตสุด | mm | mm | 40, 20 |
| `span` | `{ln, support, position, wu, V_shape, integral_slab, tf}` — ln ช่วงว่าง (m ทั้งสองหน่วย), support `simple/one_end/both_ends/cantilever`, position `interior/perimeter`, wu น้ำหนักแนวดิ่งประลัยสำหรับ IMF Ve, V_shape `gravity` (default) หรือ `constant` | m, kgf/m | m, kN/m | **ln ต้องให้** |
| `combos[]` | `{name, M_left, M_mid, M_right, V_left, V_right, V_2E?}` — M ลบ = ดึงบน, V ใส่ค่าขนาด | kgf·m, kgf | kN·m, kN | |
| `stirrups` | `{db, legs, s_end, s_mid, end_zone}` — end_zone เป็น m; check ต้องให้ s_end, s_mid | mm | mm | 10, 2, –, –, max(2h, ℓn/4) |
| `bars` (check) | `{left/mid/right: {top: [[n, db], …], bot: [[n, db], …]}}` — ชั้นนอกสุดก่อน | mm | mm | |
| `design` | `{db_options, max_layers}` | mm | mm | [16, 20, 25], 2 |
| `scope` | `{Pu, Tu, conc_load_within_2h}` | kgf | kN | — |
| `epoxy`, `lam`, `vc_eq`, `grade420_exception` | ψe, λ, สมการ Vc (`a`/`b`/`max`), εty = 0.002 | | | ไม่เคลือบ, 1.0, a, false |

## นอกขอบเขต (บอกผู้ใช้)

คาน T/L (ใช้หน้าตัดสี่เหลี่ยม bw อนุรักษ์ได้แต่ต้องบอก), deep beam, คานอัดแรง, คาน SMF (§18.6), แรงบิด, คานรับแรงตามแกน, เหล็กดัดคอม้า, คานเปลี่ยนหน้าตัด, การแอ่นตัวจริงเมื่อไม่ผ่าน Table 9.3.1.1, จุดตัดเหล็กเมื่อมีแรงจุด (สคริปต์ใช้พาราโบลา 3 จุด), เหล็กแขวนที่คานซอยมาฝาก

## ไฟล์

- `scripts/beamkit/` — `section`, `flexure`, `shear`, `detailing`, `engine` (check/design), `report`, `rcsi` (โมดูลร่วมกับสกิลเสา)
- `scripts/beam.py` — CLI · `scripts/test_beam.py` — เทียบค่ามือ + strip model ที่เขียนแยก
- `kb/` — สรุป ACI 318-19 บท 9, 18, 20, 21, 22, 24, 25 + `INDEX.md`
- `scripts/from_staad.py` + `scripts/*/staadio.py` — แปลงผล STAAD (โมดูลร่วม) · `references/staad-sign-convention.md`
- `references/si-formulas.md`, `references/si-constants-318m.md`, `references/test-results.md`
- `examples/` — `B1_design_kgfm` (ออกแบบ), `B2_check_SI` (ตรวจ), `B3_IMF_design_kgfm` (ออกแบบ IMF) พร้อมรายงาน

## ความถูกต้อง

KB ทุกบทเทียบต้นฉบับ ACI 318-19 แล้ว · ค่าคงที่ SI ของ Ch.9, 20, 22, 24, 25 เทียบเล่ม 318M-19 แล้ว · ค่า SI ใน Ch.18 (50/300 mm) แปลงจาก inch-pound ยังไม่ได้เทียบเล่ม 318M
